create definer = root@`%` trigger insert_log
    after INSERT
    on users
    for each row
begin
        insert into logs set action='create', new_data=json_object('id', new.id, 'email', new.email, 'name', new.name, 'password', new.password);
    end;

