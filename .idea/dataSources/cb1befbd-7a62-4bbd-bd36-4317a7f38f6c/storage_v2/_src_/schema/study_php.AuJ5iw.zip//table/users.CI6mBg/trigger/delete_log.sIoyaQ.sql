create definer = root@`%` trigger delete_log
    after DELETE
    on users
    for each row
begin
    insert into logs set action='delete', old_data=json_object('id', old.id, 'email', old.email, 'name', old.name, 'password', old.password);
end;

