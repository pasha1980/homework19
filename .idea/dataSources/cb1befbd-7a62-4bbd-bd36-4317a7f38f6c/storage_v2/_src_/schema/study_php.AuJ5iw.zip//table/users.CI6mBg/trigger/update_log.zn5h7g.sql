create definer = root@`%` trigger update_log
    after UPDATE
    on users
    for each row
begin
    insert into logs set action='update', old_data=json_object('id', old.id, 'email', old.email, 'name', old.name, 'password', old.password), new_data=json_object('id', new.id, 'email', new.email, 'name', new.name, 'password', new.password);
end;

